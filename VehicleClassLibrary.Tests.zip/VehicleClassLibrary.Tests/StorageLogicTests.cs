﻿using VehicleClassLibrary.Models;
using VehicleClassLibrary.Services.BuisnessLogicLayer;

namespace VehicleClassLibrary.Tests
{
    public class StorageLogicTests
    {
        //Mark this method as a unit test with the fact attribute from xUnit
        [Fact]
        public void AddVehicleToInventory_ShouldIncreaseInventoryCount()
        {
            //Arrange: Create an instance of the store logic
            StoreLogic store = new StoreLogic();

            //Create a new CarModel to add
            CarModel car = new CarModel()
            {
                Id = 1,
                Make = "Toyota",
                Model = "Camery",
                Year = 2020,
                Price = 25000m,
                NumWheels = 4,
                IsConvertible = true,
                TrunkSize = 2.5m
            };

            //Act: Add this vehicle to the inventory
            store.AddVehicleToInventory(car);

            //Retrieve the current inventory
            List<VehicleModel> inventory = store.GetInventory();

            //Assert: Verify that the vehicle was added to inventory
            Assert.Contains(car, inventory);
        }
        
        //Test for GetInventory when no vehicles have been added
        [Fact]
        public void GetInventory_ShouldReturnEmptyList_WhenNoVehiclesAdded()
        {
            //Arrange: Create instince of StoreLogic
            StoreLogic store = new StoreLogic();

            //Act: Retrieve the inventory without adding any vehicles
            List<VehicleModel> inventory = store.GetInventory();

            //Assert: the inventory should be empty
            Assert.Empty(inventory);
        }

        //Test adding a vehicle to the shopping cart
        [Fact]
        public void AddVehicleToCar_ShouldAddVehicle_WhenValidVehicleIdGiven()
        {
            //Arrange: Create an instance of the store
            StoreLogic store = new StoreLogic();

            //Create and add a vehicle
            CarModel car = new CarModel
            {
                Id = 1,
                Make = "Honda",
                Model = "Civic",
                Year = 2019,
                Price = 20000m,
                NumWheels = 4,
                IsConvertible = true,
                TrunkSize = 2.5m
            };

            store.AddVehicleToCart(car);

            //Act: Add the vehicle to the shipping cart using its Id
            int result = store.AddVehicleToCart(car.Id);
            //Retreive the shopping cart contents
            List<VehicleModel> cart = store.GetShoppingCart();

            Assert.Equal(1, result);

            //Assert: Verify that the cart has the vehicle
            Assert.Contains(cart, verify => verify.Id == car.Id);
        }

        //Test that the shopping cart returns empty when there are no vehicles
        [Fact]
        public void GetShoppingCart_ShouldReturnEmptyList_WhenNoVehiclesAdded()
        {
            //Arrange: Create an instence of the Store
            StoreLogic store = new StoreLogic();

            //Act: Retrieve the shipping cart with no added vehicles
            List<VehicleModel> cart = store.GetShoppingCart();

            //Assert that the cart is empty
            Assert.Empty(cart);
        }

        //Test that Checkout returns the correct total and clears the shopping cart
        [Fact]
        public void Checkout_ShouldReturnCorrectTotal_AndClearCart()
        {
            //Arrange: Create an instence of the Store
            StoreLogic store = new StoreLogic();

            //Create two vehacles and add them to the cart
            CarModel car1 = new CarModel
            {
                Id = 3,
                Make = "Ford",
                Model = "F-150",
                Year = 2021,
                Price = 40000m,
                NumWheels = 4,
                IsConvertible = true,
                TrunkSize = 2.5m
            };

            CarModel car2 = new CarModel
            {
                Id = 4,
                Make = "Chevrolet",
                Model = "Silverado",
                Year = 2022,
                Price = 45000m,
                NumWheels = 4,
                IsConvertible = true,
                TrunkSize = 2.5m
            };

            //Add both to inventory
            store.AddVehicleToInventory(car1);
            store.AddVehicleToInventory(car2);

            //Add the cars to the cart
            store.AddVehicleToCart(car1.Id);
            store.AddVehicleToCart(car2.Id);

            //Act: Perform the checkout operations
            decimal total = store.Checkout();

            //Retrieve the shopping cart contents after checkout
            List<VehicleModel> cartAfterCheckout = store.GetShoppingCart();

            //Assert: verify that the totals are correct ensuring all calculations like discounts are done correctly
            Assert.True(total >= (car1.Price + car2.Price) * 0.95m);
            Assert.True(total <= (car1.Price + car2.Price) * 1.05m);

            //Assert: verify that the cart is empty
            Assert.Empty(cartAfterCheckout);
        }
    }
}
